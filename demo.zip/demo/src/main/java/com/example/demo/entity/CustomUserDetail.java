package com.example.demo.entity;

public class CustomUserDetail implements UserDetails{
    private final User user;

    public CustomUserDetail(User user) {this.user = user;}
}
